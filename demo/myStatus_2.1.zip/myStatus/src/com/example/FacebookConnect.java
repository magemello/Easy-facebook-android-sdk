package com.example;

import com.example.R;
import com.easy.facebook.android.apicall.RestApi;
import com.easy.facebook.android.data.Status;
import com.easy.facebook.android.error.EasyFacebookError;
import com.easy.facebook.android.facebook.FBLoginManager;
import com.easy.facebook.android.facebook.Facebook;
import com.easy.facebook.android.facebook.LoginListener;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


public class FacebookConnect extends Activity   implements LoginListener {

	private FBLoginManager fbManager;
	Intent intentResult;

	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		intentResult=new Intent(getApplicationContext(),IntentResult.class);
		
		shareFacebook();
	}

	public void shareFacebook() {
		String permissions[] = {"user_status","read_stream","offline_access"};
		
		fbManager = new FBLoginManager(this,R.layout.black,"FacebookApplicationID",permissions);


		if (fbManager.existsSavedFacebook()) {
			fbManager.loadFacebook();
		} else {

			fbManager.login();
		}
	}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    	fbManager.loginSuccess(data);
    }
    
	public void loginFail() {
		fbManager.displayToast("Login failed!");
		
	}
	
	public void logoutSuccess() {
		fbManager.displayToast("Logout success!");
	}

	public void loginSuccess(Facebook facebook) {
					
		RestApi restApi= new RestApi(facebook);

		Status status = new Status();
		
		try {
			status = restApi.getCurrentStatus();
		} catch (EasyFacebookError e) {
			e.toString();
		}
		
		String pkg=getPackageName(); 
		intentResult.putExtra(pkg+".myMessage",status.getMessage());
		intentResult.putExtra(pkg+".myId",status.getStatus_id());
    	startActivity(intentResult);
		


	}
}